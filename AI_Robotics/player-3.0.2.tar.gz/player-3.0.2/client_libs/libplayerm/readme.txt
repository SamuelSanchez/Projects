Matlab/Octave Player Client

This is a Matlab/Octave Player Client, developed at the on the Automation and Control Institute (ACIN) of the Vienna University of Technology and released under the GNU Lesser General Public License (LGPL). 

-----> Not all interfaces/proxies are currently present but the code shows how simple it is to extend the client to other interfaces/proxies


The client is testet with
player 2.0.7
player 3.0.0
                    - markus bader (bader@acin.tuwien.ac.at)

