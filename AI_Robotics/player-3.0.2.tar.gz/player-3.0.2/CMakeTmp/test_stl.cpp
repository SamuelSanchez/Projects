#include <string>
int main () {std::string a = "blag"; return 0;}
